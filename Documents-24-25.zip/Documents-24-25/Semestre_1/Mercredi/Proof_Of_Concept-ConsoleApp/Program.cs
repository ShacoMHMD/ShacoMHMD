﻿using MongoDB.Driver;

const string connectionUri = "mongodb://ShacoMDB:1228@localhost:27017/?authSource=ProofOfConcept";

var dbClient = new MongoClient(connectionUri);


if (dbClient == null)
{
    Console.WriteLine("Connection Fails");
    Environment.Exit(0);
}

var Collection = dbClient.GetDatabase("ProofOfConcept");

Console.WriteLine(" ");

var listCollection = Collection.ListCollectionNames().ToList();

Console.WriteLine(listCollection.ToString());


