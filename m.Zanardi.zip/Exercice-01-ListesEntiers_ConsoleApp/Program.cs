﻿// See https://aka.ms/new-console-template for more information

List<int> ListesEntier = new List<int>();

Random rnd = new Random();

Console.WriteLine("Affichage d'une liste avec seulement des nombres paires");

for (int i = 0; i <= 10; i++) 
{ 
    ListesEntier.Add(rnd.Next(101));    
}

foreach (var item in ListesEntier)
{
   
        Console.WriteLine(item);
}

Console.WriteLine("");
Console.WriteLine("La somme total des chiffres de la listes est " + );