﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_02_TriVoitures_ConsoleApp
{
    class Voitures : IComparable<Voitures>
    {
        public string Marque{ get; set; }
        public string Modele { get; set; }
        public int Puissance{ get; set; }

        public Voitures(string marque, string modele, int puissance)
        {
            Marque = marque;
            Modele = modele;
            Puissance = puissance;
        }

        public string ToString() 
        { 
            return Marque + " " + Modele + " " + Puissance;
        }

        public void Voiture(string marque, string modele, int puissance) 
        {
            Marque = marque;
            Modele = modele;
            Puissance = puissance; 
        }

        public int CompareTo(Voitures? obj)
        {
            return Puissance.CompareTo(obj.Puissance);
        }
    }
}
