﻿using Exercice_02_TriVoitures_ConsoleApp;

List<Voitures> ListVoitures = new List<Voitures>();

ListVoitures.Add(new Voitures("Hennessey", "Venom GT", 1244));
ListVoitures.Add(new Voitures("Bugatti", "Centodieci", 1600));
ListVoitures.Add(new Voitures("Zenvo", "ST1", 1104));
ListVoitures.Add(new Voitures("GTA", "Spano", 925));
ListVoitures.Add(new Voitures("Ferrari", "LaFerrari", 963));
ListVoitures.Add(new Voitures("Aston Martin", "Valkyrie", 1176));
ListVoitures.Add(new Voitures("Bristol", "T Fighter", 1012));
ListVoitures.Add(new Voitures("SSC", "Tuatara", 1750));
ListVoitures.Add(new Voitures("McLaren", "Speedtail", 1070));
ListVoitures.Add(new Voitures("Koenigsegg", "Regera", 1500));

ListVoitures.Sort();

foreach (var Car in ListVoitures)
{
    Console.WriteLine(Car.ToString());
}

//List<Voitures> tri_bulle(List<Voitures> listCar) 
//{
//    int passage = 0;
//    bool permutation = true;
//    int onDoing;

//    while (permutation) 
//    { 
//        permutation = false;
//        passage++;
//        for (onDoing = 0; onDoing < listCar.Count - passage; onDoing++) 
//        { 
//            if (ListVoitures[onDoing].Puissance > ListVoitures[onDoing + 1].Puissance ) { 
da
//            Voitures car = ListVoitures[onDoing];
//            ListVoitures[onDoing] = ListVoitures[onDoing + 1];
//            ListVoitures[onDoing + 1] = car;
//            }
//        }
//    }
//    return listCar;
//}
//var listcar = tri_bulle(ListVoitures);
//foreach (Voitures car in listcar) 
//{
//    Console.WriteLine(car.ToString());
//}

